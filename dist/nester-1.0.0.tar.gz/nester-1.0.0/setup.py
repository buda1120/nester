from distutils.core import setup
setup(
    name    = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'poprun',
    author_email = 'yongjh0103@outlook.com',
    url = 'https://github.com/buda1120/nester',
    description = 'A simple printer of nested lists',
    )
